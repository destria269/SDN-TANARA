<?php
$nilai1=85;
$nilai2=85;
$nilai3=85;
$nilai4=95;
$nilai5=95;
$hasil=$nilai1+$nilai2+$nilai3+$nilai4+$nilai5;
$rata=$hasil / 5;
echo "Nilai rata - ratanya adalah $rata";
?>